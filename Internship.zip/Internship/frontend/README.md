# Installation Guide

## git clone <https://github.com/Ne0sky/HOD-Dashboard-updated.git>
## cd HOD-Dashboard-updated
## npm install
## npm run dev


import React from 'react'

function Career() {
  return (
    <div>Career</div>
  )
}

export default Career
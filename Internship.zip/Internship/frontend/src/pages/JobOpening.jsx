import React from 'react'
import Banner from '../components/Banner'
function JobOpening() {
  return (
    <div>
        <Banner/>
    </div>
  )
}

export default JobOpening
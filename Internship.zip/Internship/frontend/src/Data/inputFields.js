const inputFieldData = [
{
    title:"Dish Name",
    value:"dishName"
},
{
    title:"Veg or Non-veg",
},
{
    title:"Popularity State",
}
]

export default inputFieldData;